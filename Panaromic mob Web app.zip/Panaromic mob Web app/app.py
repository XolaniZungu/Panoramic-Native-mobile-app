from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///panaromicdb.db'
app.config['SECRET_KEY'] = "random string"

db = SQLAlchemy(app)

class students(db.Model):
 id = db.Column('student_id', db.Integer, primary_key = True)
 studentid = db.Column(db.String(100)) 
 name = db.Column(db.String(100))
 email = db.Column(db.String(100))
 password = db.Column(db.String(250))
 qualification = db.Column(db.String(10))
 
def __init__(self, studentid, name, email, password, qualification):
 self.studentid = studentid  
 self.name = name
 self.email = email
 self.password = password
 self. qualification = qualification
 
@app.route('/')
def show_all():
  return render_template('index.html', students = students.query.all())
@app.route('/application')
def application():
  return render_template('Appliation_form.html')
@app.route('/new', methods = ['GET', 'POST'])
def new():
    if request.method == 'POST':
      if not request.form.get('name') or not request.form.get('email') or not request.form.get('password'):
          flash('Please enter all the fields', 'error')
          return redirect(url_for('new'))
      else:
          student = students (request.form.get('name') ,request.form.get('email'), 
          request.form.get('password'))


          db.session.add(student)
          db.session.commit()
          flash('Record was successfully added')
          return redirect(url_for('show_all'))
    return render_template('Login.html')

@app.route('/login', methods=['POST', 'GET'])
def login():
  if request.method == 'POST':
        name = request.form.get('name')
        password = request.form.get('password')
    
        user = students.query.filter_by(name=name).first()
    
        if not user or user.password != password:
              flash('Wrong details')
              return redirect(url_for('login'))
        else:
              return redirect(url_for('show_all'))
  return render_template('Login.html')
                
if __name__ == '__main__':
 db.create_all()
 app.run(debug = True)